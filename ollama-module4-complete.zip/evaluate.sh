#!/usr/bin/env bash
set -u

NAMESPACE="llm-serving"

ollama_available=0
model_available=0
deployment_ready=0
service_ready=0
hpa_configured=0
metrics_available=0
inference_healthy=0
self_healing_ready=0

if curl -fsS http://localhost:11434/api/tags >/tmp/eval-ollama-tags.json 2>/dev/null; then
  ollama_available=1
  if grep -q '"name":"phi3:mini"' /tmp/eval-ollama-tags.json; then
    model_available=1
  fi
fi

if kubectl get deployment ollama-gateway -n "$NAMESPACE" >/dev/null 2>&1; then
  desired="$(kubectl get deployment ollama-gateway -n "$NAMESPACE" -o jsonpath='{.spec.replicas}' 2>/dev/null || echo 0)"
  ready="$(kubectl get deployment ollama-gateway -n "$NAMESPACE" -o jsonpath='{.status.readyReplicas}' 2>/dev/null || echo 0)"
  if [ "${desired:-0}" -ge 1 ] && [ "${ready:-0}" -ge 1 ]; then
    deployment_ready=1
  fi
fi

if kubectl get service ollama-gateway-service -n "$NAMESPACE" >/dev/null 2>&1; then
  endpoints="$(kubectl get endpoints ollama-gateway-service -n "$NAMESPACE" -o jsonpath='{.subsets[*].addresses[*].ip}' 2>/dev/null || true)"
  if [ -n "$endpoints" ]; then
    service_ready=1
  fi
fi

if kubectl get hpa ollama-gateway-hpa -n "$NAMESPACE" >/dev/null 2>&1; then
  min="$(kubectl get hpa ollama-gateway-hpa -n "$NAMESPACE" -o jsonpath='{.spec.minReplicas}' 2>/dev/null || echo 0)"
  max="$(kubectl get hpa ollama-gateway-hpa -n "$NAMESPACE" -o jsonpath='{.spec.maxReplicas}' 2>/dev/null || echo 0)"
  if [ "$min" = "1" ] && [ "$max" = "2" ]; then
    hpa_configured=1
  fi
fi

if kubectl top pods -n "$NAMESPACE" >/dev/null 2>&1; then
  metrics_available=1
fi

pod="$(kubectl get pods -n "$NAMESPACE" -l app=ollama-gateway -o jsonpath='{.items[0].metadata.name}' 2>/dev/null || true)"

if [ -n "$pod" ]; then
  if kubectl exec -n "$NAMESPACE" "$pod" -- python3 -c '
import json, urllib.request
data=json.dumps({"prompt":"Say OK in one word."}).encode()
req=urllib.request.Request("http://localhost:8080/generate", data=data, headers={"Content-Type":"application/json"}, method="POST")
with urllib.request.urlopen(req, timeout=180) as r:
    body=json.loads(r.read().decode())
assert body.get("response")
' >/dev/null 2>&1; then
    inference_healthy=1
  fi
fi

if [ "$deployment_ready" -eq 1 ]; then
  old_uid="$(kubectl get pod "$pod" -n "$NAMESPACE" -o jsonpath='{.metadata.uid}' 2>/dev/null || true)"

  kubectl delete pod "$pod" -n "$NAMESPACE" --wait=false >/dev/null 2>&1 || true

  replacement=""
  for i in $(seq 1 60); do
    candidate="$(kubectl get pods -n "$NAMESPACE" -l app=ollama-gateway \
      -o jsonpath='{range .items[*]}{.metadata.name}{"|"}{.metadata.uid}{"|"}{.status.phase}{"|"}{.status.containerStatuses[0].ready}{"\n"}{end}' \
      2>/dev/null | awk -F'|' -v old="$old_uid" '$2 != old && $3 == "Running" && $4 == "true" {print $1; exit}')"
    if [ -n "$candidate" ]; then
      replacement="$candidate"
      break
    fi
    sleep 2
  done

  if [ -n "$replacement" ]; then
    if kubectl exec -n "$NAMESPACE" "$replacement" -- \
      python3 -c 'import urllib.request; urllib.request.urlopen("http://localhost:8080/health", timeout=3)' \
      >/dev/null 2>&1; then
      self_healing_ready=1
    fi
  fi
fi

total=$((ollama_available + model_available + deployment_ready + service_ready + hpa_configured + metrics_available + inference_healthy + self_healing_ready))
score=$((total * 100 / 8))

cat <<EOF
{
  "ollama_available": $ollama_available,
  "model_available": $model_available,
  "deployment_ready": $deployment_ready,
  "service_ready": $service_ready,
  "hpa_configured": $hpa_configured,
  "metrics_available": $metrics_available,
  "inference_healthy": $inference_healthy,
  "self_healing_ready": $self_healing_ready,
  "score": $score
}
EOF

#!/usr/bin/env bash
set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
NAMESPACE="llm-serving"
MODEL="phi3:mini"
IMAGE="ollama-inference-gateway:1.0"

echo "=============================================="
echo " Module 4 - Ollama AI Model Serving Lab"
echo "=============================================="

echo
echo "[1/8] Checking required commands..."
for cmd in ollama docker minikube kubectl curl ss; do
  command -v "$cmd" >/dev/null 2>&1 || {
    echo "ERROR: required command not found: $cmd"
    exit 1
  }
done

echo
echo "[2/8] Checking host resources..."
echo "CPU: $(nproc)"
free -h
df -h /

echo
echo "[3/8] Checking Ollama service..."
if ! systemctl is-active --quiet ollama; then
  echo "ERROR: Ollama service is not active."
  echo "Run: sudo systemctl start ollama"
  exit 1
fi

echo
echo "[4/8] Verifying model: $MODEL"
if ! ollama list | awk 'NR > 1 {print $1}' | grep -Fxq "$MODEL"; then
  echo "ERROR: $MODEL is not installed."
  ollama list
  exit 1
fi

echo
echo "[5/8] Configuring Ollama host access..."
sudo mkdir -p /etc/systemd/system/ollama.service.d
sudo tee /etc/systemd/system/ollama.service.d/override.conf >/dev/null <<'EOF'
[Service]
Environment="OLLAMA_HOST=0.0.0.0:11434"
EOF

sudo systemctl daemon-reload
sudo systemctl restart ollama
sleep 3

if ! systemctl is-active --quiet ollama; then
  sudo systemctl status ollama --no-pager
  exit 1
fi

if ! ss -lnt | grep -q ':11434'; then
  echo "ERROR: Ollama is not listening on port 11434."
  ss -lnt | grep 11434 || true
  exit 1
fi

echo
echo "[6/8] Verifying Ollama API..."
curl -fsS http://localhost:11434/api/tags >/tmp/ollama-tags.json
echo "Ollama API is reachable."

echo
echo "[7/8] Checking Minikube..."
if ! minikube status >/dev/null 2>&1; then
  minikube start --driver=docker --cpus=4 --memory=8192
fi

minikube status
kubectl get nodes

echo
echo "Enabling Metrics Server..."
minikube addons enable metrics-server
kubectl rollout status deployment/metrics-server -n kube-system --timeout=180s

echo
echo "Testing host Ollama access from Minikube..."
if ! minikube ssh -- curl -fsS \
  http://host.minikube.internal:11434/api/tags >/dev/null; then
  echo "ERROR: Minikube cannot reach host Ollama."
  echo "Run:"
  echo "  ss -lnt | grep 11434"
  echo "  minikube ssh -- curl http://host.minikube.internal:11434/api/tags"
  exit 1
fi

echo
echo "[8/8] Building gateway image inside Minikube..."
cd "$PROJECT_DIR"
minikube image build -t "$IMAGE" ./gateway

echo
echo "Creating namespace..."
kubectl apply -f k8s/namespace.yaml

echo
echo "Environment preparation completed."
echo
echo "Next direct test:"
echo "curl -s http://localhost:11434/api/generate -H 'Content-Type: application/json' -d '{\"model\":\"phi3:mini\",\"prompt\":\"Explain Kubernetes in one sentence.\",\"stream\":false}'"

# Module 4 — AI Model Serving with Ollama, Autoscaling, Reliability Management and Inference Operations

Difficulty: Easy
Duration: about 45 minutes
Platform: Ubuntu Linux VM + Ollama + Minikube + Kubernetes
Model: phi3:mini

## Architecture

The LLM stays on the host in Ollama. Kubernetes manages a stateless inference gateway.

Client -> Kubernetes Service -> Gateway Deployment -> host.minikube.internal:11434 -> Ollama -> phi3:mini

HPA scales the gateway from 1 to 2 replicas. It does NOT create additional copies of the LLM.

This design is intentional for a 4-vCPU / 15-GiB VM.

## 1. Prepare the environment

```bash
cd ~/ollama_serving
chmod +x create_env.sh evaluate.sh delete_env.sh
./create_env.sh
```

The script verifies Ollama and phi3:mini, configures host access for Minikube, verifies connectivity, checks Minikube, enables Metrics Server, and builds the small gateway image inside Minikube.

Do not open TCP/11434 to the public Internet.

## 2. Direct Ollama validation

```bash
ollama list
curl -s http://localhost:11434/api/tags
```

Run inference:

```bash
curl -s http://localhost:11434/api/generate \
  -H "Content-Type: application/json" \
  -d '{
    "model": "phi3:mini",
    "prompt": "Explain Kubernetes in one sentence.",
    "stream": false,
    "options": {
      "num_ctx": 1024,
      "num_predict": 40
    }
  }'
```

Measure baseline latency:

```bash
/usr/bin/time -f '\nElapsed: %e seconds' \
curl -s http://localhost:11434/api/generate \
  -H "Content-Type: application/json" \
  -d '{
    "model": "phi3:mini",
    "prompt": "What is a Kubernetes pod?",
    "stream": false,
    "options": {
      "num_ctx": 1024,
      "num_predict": 40
    }
  }' > /tmp/ollama-baseline.json

cat /tmp/ollama-baseline.json
```

## 3. Deploy the gateway

```bash
kubectl apply -f k8s/namespace.yaml
kubectl apply -f k8s/deployment.yaml

kubectl rollout status deployment/ollama-gateway \
  -n llm-serving --timeout=180s

kubectl get pods -n llm-serving -o wide
```

Expected: one gateway Pod is Running and Ready.

## 4. Create the Service

```bash
kubectl apply -f k8s/service.yaml
kubectl get svc -n llm-serving
kubectl get endpoints -n llm-serving
```

Create a local access tunnel:

```bash
kubectl port-forward -n llm-serving svc/ollama-gateway-service 8085:8080
```

Keep this terminal running.

## 5. Health and readiness

In another terminal:

```bash
curl -i http://localhost:8085/health
curl -i http://localhost:8085/ready
```

Both should return HTTP 200.

## 6. Inference through Kubernetes

```bash
curl -s http://localhost:8085/generate \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "Explain the purpose of a Kubernetes Service."
  }'
```

Measure gateway latency:

```bash
/usr/bin/time -f '\nElapsed: %e seconds' \
curl -s http://localhost:8085/generate \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "What is Kubernetes autoscaling?"
  }' > /tmp/gateway-response.json

cat /tmp/gateway-response.json
```

## 7. Verify Metrics Server

```bash
kubectl get deployment metrics-server -n kube-system
kubectl top pods -n llm-serving
```

If metrics are not ready immediately, wait 30-60 seconds and retry.

## 8. Configure HPA

```bash
kubectl apply -f k8s/hpa.yaml
kubectl get hpa -n llm-serving
kubectl describe hpa ollama-gateway-hpa -n llm-serving
```

The HPA is based on gateway CPU utilization.

## 9. Generate inference load

Keep the port-forward terminal running.

In another terminal:

```bash
for i in 1 2 3 4 5 6
do
  (
    while true
    do
      curl -s http://localhost:8085/generate \
        -H "Content-Type: application/json" \
        -d '{
          "prompt": "Explain Kubernetes deployments, Services, Pods, autoscaling, reliability and inference operations."
        }' > /dev/null
    done
  ) &
done
```

Monitor:

```bash
watch -n 5 '
kubectl get pods -n llm-serving
echo
kubectl get hpa -n llm-serving
echo
kubectl top pods -n llm-serving
'
```

The intended gateway behavior is 1 replica under normal load and up to 2 replicas under sustained CPU load.

## 10. Stop the load

Stop the request loops:

```bash
pkill -f 'curl -s http://localhost:8085/generate'
```

Then:

```bash
kubectl get hpa -n llm-serving
kubectl get deployment -n llm-serving
```

After the HPA scale-down stabilization period, the gateway should return toward 1 replica.

## 11. Reliability / self-healing

```bash
kubectl get pods -n llm-serving
```

Delete a gateway Pod:

```bash
kubectl delete pod -n llm-serving <POD_NAME>
```

Replace `<POD_NAME>` with the current gateway Pod name.

Watch:

```bash
kubectl get pods -n llm-serving -w
```

A replacement Pod should become Running and Ready.

Stop the watch with Ctrl+C.

## 12. Verify inference after self-healing

```bash
curl -i http://localhost:8085/health
curl -s http://localhost:8085/generate \
  -H "Content-Type: application/json" \
  -d '{
    "prompt": "What is self-healing in Kubernetes?"
  }'
```

## 13. Final verification

```bash
kubectl get all -n llm-serving
kubectl get hpa -n llm-serving
kubectl top pods -n llm-serving
kubectl get endpoints -n llm-serving
ollama ps
```

## 14. Automated evaluation

Run:

```bash
./evaluate.sh
```

The evaluator returns JSON only.

It checks Ollama, the model, Deployment readiness, Service endpoints, HPA configuration, Metrics Server, inference health, and performs a controlled Pod replacement to verify self-healing.

## 15. Cleanup

```bash
./delete_env.sh
```

The cleanup removes only the lab Kubernetes namespace/resources. It does not remove Ollama, the installed models, or Minikube.

## Troubleshooting

### Check Ollama

```bash
systemctl status ollama --no-pager
curl -s http://localhost:11434/api/tags
ss -lnt | grep 11434
```

The Ollama service must listen on port 11434 on a non-loopback address so Minikube can reach it.

### Test host access from Minikube

```bash
minikube ssh -- curl -fsS http://host.minikube.internal:11434/api/tags
```

### Check gateway logs

```bash
kubectl logs -n llm-serving deployment/ollama-gateway
```

### Check HPA

```bash
kubectl get hpa -n llm-serving
kubectl describe hpa ollama-gateway-hpa -n llm-serving
kubectl top pods -n llm-serving
```

Do not change this design to run two Ollama model replicas on this VM.

#!/usr/bin/env bash
set -euo pipefail

NAMESPACE="llm-serving"

echo "Cleaning Module 4 Kubernetes resources..."

if kubectl get namespace "$NAMESPACE" >/dev/null 2>&1; then
  kubectl delete namespace "$NAMESPACE" --wait=true
  echo "Namespace deleted."
else
  echo "Namespace does not exist."
fi

echo
echo "Ollama was NOT removed."
echo "Ollama models were NOT removed."
echo "Minikube was NOT deleted."
echo "The gateway image remains in Minikube."

import hashlib
import json
import os
import time
import urllib.error
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

OLLAMA_URL = os.getenv("OLLAMA_URL", "http://host.minikube.internal:11434").rstrip("/")
MODEL = os.getenv("OLLAMA_MODEL", "phi3:mini")
CPU_WORK_MS = int(os.getenv("CPU_WORK_MS", "250"))

def encode_json(value):
    return json.dumps(value).encode("utf-8")

def cpu_work(milliseconds):
    if milliseconds <= 0:
        return
    deadline = time.perf_counter() + milliseconds / 1000.0
    payload = b"ollama-gateway-cpu-work" * 4096
    digest = b""
    while time.perf_counter() < deadline:
        digest = hashlib.sha256(payload + digest).digest()

def get_tags():
    request = urllib.request.Request(
        f"{OLLAMA_URL}/api/tags",
        headers={"Accept": "application/json"},
        method="GET",
    )
    with urllib.request.urlopen(request, timeout=5) as response:
        return json.loads(response.read().decode("utf-8"))

def generate(prompt):
    body = {
        "model": MODEL,
        "prompt": prompt,
        "stream": False,
        "keep_alive": "5m",
        "options": {
            "num_ctx": 1024,
            "num_predict": 60
        }
    }
    request = urllib.request.Request(
        f"{OLLAMA_URL}/api/generate",
        data=encode_json(body),
        headers={"Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=180) as response:
        return json.loads(response.read().decode("utf-8"))

class Handler(BaseHTTPRequestHandler):
    server_version = "OllamaGateway/1.0"

    def send_json(self, status, value):
        data = encode_json(value)
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        if self.path == "/health":
            self.send_json(200, {"status": "ok"})
            return

        if self.path == "/ready":
            try:
                tags = get_tags()
                names = [item.get("name", "") for item in tags.get("models", [])]
                if MODEL not in names:
                    self.send_json(503, {"status": "not_ready", "model": MODEL})
                    return
                self.send_json(200, {"status": "ready", "model": MODEL})
            except Exception as exc:
                self.send_json(503, {"status": "not_ready", "error": str(exc)})
            return

        self.send_json(404, {"error": "not found"})

    def do_POST(self):
        if self.path != "/generate":
            self.send_json(404, {"error": "not found"})
            return

        try:
            length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(length)
            body = json.loads(raw.decode("utf-8"))
            prompt = body.get("prompt")

            if not isinstance(prompt, str) or not prompt.strip():
                self.send_json(400, {"error": "prompt is required"})
                return

            # Small stateless CPU work makes gateway CPU measurable for HPA.
            # It does not load another LLM.
            cpu_work(CPU_WORK_MS)

            result = generate(prompt)

            self.send_json(200, {
                "model": MODEL,
                "response": result.get("response", ""),
                "ollama_total_duration_ns": result.get("total_duration"),
                "ollama_load_duration_ns": result.get("load_duration"),
                "ollama_prompt_eval_duration_ns": result.get("prompt_eval_duration"),
                "ollama_eval_duration_ns": result.get("eval_duration")
            })

        except urllib.error.HTTPError as exc:
            try:
                detail = exc.read().decode("utf-8")
            except Exception:
                detail = str(exc)
            self.send_json(502, {"error": "ollama request failed", "detail": detail})
        except Exception as exc:
            self.send_json(500, {"error": "gateway request failed", "detail": str(exc)})

    def log_message(self, fmt, *args):
        print("%s - %s" % (self.address_string(), fmt % args), flush=True)

if __name__ == "__main__":
    server = ThreadingHTTPServer(("0.0.0.0", 8080), Handler)
    print(
        f"Gateway listening on :8080; Ollama={OLLAMA_URL}; "
        f"model={MODEL}; CPU_WORK_MS={CPU_WORK_MS}",
        flush=True,
    )
    server.serve_forever()
